
const axios = require('axios');

const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbx69N4kArtsmCgUMacv0dkM91ti2wDTZxiQuLJJv7-RNDMgsHI6s6dWsHb9yHBSkQEW/exec';
const PAGE_NAME = 'eps';

async function getAnimes(page = 1, limit = 10) {
  const res = await axios.post(SCRIPT_URL, {
    Function: 'ExportJSON',
    page: PAGE_NAME
  });

  const allData = res.data.data || [];
  const total = allData.length;
  const totalPages = Math.ceil(total / limit);
  const paginated = allData.slice((page - 1) * limit, page * limit);

  return {
    result: 'success',
    currentPage: Number(page),
    totalPages,
    totalItems: total,
    perPage: Number(limit),
    data: paginated
  };
}

async function createAnime(data) {
  await axios.post(SCRIPT_URL, {
    Function: 'CreateRow',
    page: PAGE_NAME,
    data: JSON.stringify(Object.values(data))
  });
  return { result: 'success', message: 'Anime criado' };
}

async function updateAnime(id, newData) {
  return { result: 'error', message: 'Update não implementado ainda no Google Script' };
}

async function deleteAnime(id) {
  return { result: 'error', message: 'Delete não implementado ainda no Google Script' };
}

module.exports = {
  getAnimes,
  createAnime,
  updateAnime,
  deleteAnime
};
