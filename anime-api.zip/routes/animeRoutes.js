
const express = require('express');
const router = express.Router();
const sheetService = require('../services/sheetService');

router.get('/', async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  const data = await sheetService.getAnimes(page, limit);
  res.json(data);
});

router.post('/', async (req, res) => {
  const result = await sheetService.createAnime(req.body);
  res.json(result);
});

router.put('/:id', async (req, res) => {
  const result = await sheetService.updateAnime(req.params.id, req.body);
  res.json(result);
});

router.delete('/:id', async (req, res) => {
  const result = await sheetService.deleteAnime(req.params.id);
  res.json(result);
});

module.exports = router;
