const express = require("express");
const axios = require("axios");
const app = express();

const PORT = process.env.PORT || 3000;

// Middleware pra aceitar JSON
app.use(express.json());

// Rota de teste
app.get("/", (req, res) => {
  res.send("API de Animes online!");
});

// Puxa dados da planilha com base na página
app.get("/api/animes", async (req, res) => {
  const page = req.query.page || "1";

  const url = "https://script.google.com/macros/s/AKfycbx69N4kArtsmCgUMacv0dkM91ti2wDTZxiQuLJJv7-RNDMgsHI6s6dWsHb9yHBSkQEW/exec";
  
  try {
    const response = await axios.post(url, {
      Function: "ExportJSON",
      page: "eps"
    });

    const allData = response.data;
    const perPage = 10;
    const pagedData = allData.slice((page - 1) * perPage, page * perPage);

    res.json(pagedData);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao buscar dados da planilha" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});