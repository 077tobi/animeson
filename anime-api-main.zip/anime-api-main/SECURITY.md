# Security Policy

## Supported Versions

The following table lists all the versions currently supported with security updates.

| Version | Supported |
| ------- | --------- |
| >=0.1.0 | ✅        |

## Reporting a Vulnerability

To report a vulnerability, send an email to rafabradleyrb at gmail.com
